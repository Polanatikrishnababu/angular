import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  constructor(private service: ServiceService, private route: Router) { }

  ngOnInit() {
  }

  logout() {
    if (this.service.logout()) {
      this.route.navigate['/home/login']
    }
    else
      alert("Failed to logout");

  }
}
