import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {

  constructor(private service: ServiceService, private route: Router) { }

  ngOnInit() {
  }

  logout() {
    if (this.service.logout()) {
      this.route.navigate['/home/login']
    }
    else
      alert("Failed to logout");

  }

}
