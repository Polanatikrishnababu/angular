import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { CashTransferComponent } from './cash-transfer/cash-transfer.component';
import { TransactionsComponent } from './transactions/transactions.component';
import { ViewComponent } from './view/view.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { AuthGuardGuard } from './guards/auth-guard.guard';
import { AccountComponent } from './account/account.component';
import { AuthGuard1Guard } from './guards/auth-guard1.guard';


const routes: Routes =
  [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    {
      path: 'home',
      component: HomeComponent,
      children: [
        {
          path: 'login',
          component: LoginComponent,
        },
        {
          path: 'signup',
          component: SignUpComponent,
        }
      ]
    },
    {
      path: 'account',
    
      component: AccountComponent,
     
      children: [
        {
          path: 'view',
          component: ViewComponent
        },

        {
          path: 'balance',
          component: ShowBalanceComponent
        },
        {
          path: 'deposit',
          component: DepositComponent
        },
        {
          path: 'withdraw',
          component: WithdrawComponent
        },
        {
          path: 'cashtransfer',
          component: CashTransferComponent
        },
        {
          path: 'transactions',
          component: TransactionsComponent
        }
      ]
    }


  ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
