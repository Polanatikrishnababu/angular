import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { ServiceService } from '../service.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardGuard implements CanActivate {
  constructor(private service:ServiceService,private route:Router){}
  canActivate(): boolean {
    if(this.service.isLoggedIn()){
      this.route.navigate['/account/view'];
      return false;
    }
    else{
      return true;
    }
  }

  canActivateChild():boolean{
    if(this.service.isLoggedIn()){
      this.route.navigate['/account/view'];
      return false;
    }
    return true;
  }
  
}
