import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Router } from '@angular/router';
import { Customer } from 'src/Models/Customer';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  service:ServiceService;
  router:Router;

  constructor(service:ServiceService,router:Router) { 
    this.service=service;
    this.router=router;
  }
  customers:Customer[]=[];
  isLogin:boolean=true;


  login(data:any){
    if(this.service.login(data)){
      this.isLogin=this.service.isLogin;
      this.router.navigate(['/account/view']);
    }else{
      alert("Values does not matched!")
    }
  }





  ngOnInit() {
    this.service.logout();
    this.customers=this.service.getCustomers();
  }

}
