import { Injectable } from '@angular/core';
import { Customer } from 'src/Models/Customer';
import { Transactions } from 'src/Models/Transactions';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {



  isLogin: boolean = false;
  customers: Customer[] = [];
  transactions: Transactions[] = [];
  tempTransaction: Transactions[] = [];
  fetched: boolean = false;
  fetchedT: boolean = false;
  createdAccount: Customer;
  http: any;
  getCustomers(): Customer[] {
    return this.customers;
  }

  isLoggedIn(): boolean {
    return this.isLogin;
  }

  logout(): boolean {
    this.isLogin = !this.isLogin;
    return true;
  }

  login(data: any): boolean {
    let caccount = data.caccount;
    let cpassword = data.cpassword;

    for (let a of this.customers) {
      console.log(a.caccount + " " + a.cpassword)
      console.log(this.customers)
      if (caccount == a.caccount && cpassword == a.cpassword) {

        alert("Value Matched!")
        this.isLogin = !this.isLogin;
        return true;
      } else {
        continue;
      }

    }
    return false;
  }


  showBalance(data: any): number {
    let caccount = data.caccount;
    console.log(caccount);
    for (let i = 0; i < this.customers.length; i++) {
      if (caccount == this.customers[i].caccount) {
        let cbalance = this.customers[i].cbalance;
        return cbalance;
      } else {
        continue;
      }
    }
    alert("Account No does not matched!")
  }


  depositeBalance(caccount_first: number, cbalance: number) {
    console.log(caccount_first, cbalance)

    for (let i = 0; i < this.customers.length; i++) {
      if (caccount_first == this.customers[i].caccount) {
        let depositeB: number = this.customers[i].cbalance;
        this.customers[i].cbalance = parseInt(depositeB.toString()) + parseInt(cbalance.toString());
        alert("Amount Deposited from " + caccount_first + "\nUpdated Balance : " + this.customers[i].cbalance);
        break;
      }
    }
  }

  constructor() {
    // this.fetchCustomers();
    // this.fetchTransactions();
  }

  add(name: string, phone: number, password: string, city: string) {
    // Customer.caccount=phone;
    // Customer.cbalance=5000;
    var b = new Customer(phone, name, phone, password, city, 5000);
    this.customers.push(b);
    return phone;
  }
  withdrawBalance(caccount_first: number, cbalance: number) {
    for (let i = 0; i < this.customers.length; i++) {
      console.log(this.customers[i])
      if (caccount_first == this.customers[i].caccount) {
        let withdrawB: number = this.customers[i].cbalance;
        this.customers[i].cbalance = parseInt(withdrawB.toString()) - parseInt(cbalance.toString());
        alert("Amount Withdrawn from " + caccount_first + "\nUpdated Balance : " + this.customers[i].cbalance);
        break;
      }
    }
  }

  // add(e:Customer){
  //   this.customers.push(e);
  //   var myJSON = JSON.stringify(this.customers);
  // }
  addTransactions(createdTransaction: Transactions): any {
    throw new Error("Method not implemented.");
  }
  addTransaction(e: Transactions) {
    this.transactions.push(e);
  }
  miniStatement(caccount: string): Transactions[] {
    this.tempTransaction = [];
    for (let i = 0; i < this.transactions.length; i++) {
      let e = this.transactions[i];
      if (caccount == e.taccount_sender) {
        this.tempTransaction.push(e);
      }
    }
    return this.tempTransaction;
  }

  fetchTransactions() {
    this.http.get('./assets/Transactions.json')
      .subscribe
      (
        data => {
          if (!this.fetchedT) {
            this.convertTransaction(data);
            this.fetchedT = true;
          }
        }
      );
  }
  convertTransaction(dataT: any) {
    for (let o of dataT) {
      let e = new Transactions(o.tid, o.taccount_sender, o.taccount_reciver, o.tamount, o.ttype);
      this.transactions.push(e);
      console.log(this.transactions)
    }
  }



}
