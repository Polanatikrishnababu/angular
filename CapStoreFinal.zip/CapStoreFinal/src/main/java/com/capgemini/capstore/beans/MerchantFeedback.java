package com.capgemini.capstore.beans;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;






@Entity
@Table(name = "capstore_merchant_feedbacks43")
public class MerchantFeedback {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "merchant_feedback_seq_gen")
	@SequenceGenerator(name = "merchant_feedback_seq_gen", initialValue = 10000, sequenceName = "merchant_feedback_seq")
	private long feedback_id;
	@Column(length = 256)
	private String merchantresponse;
	@Column(length = 256)
	private String customerFeedback;
	private String adminComment;
	private String customerstatus;
	private String merchantrstatus;
	private long customerId;
	private long merchantId;
	
	
	
	
	public MerchantFeedback() {
		super();
		// TODO Auto-generated constructor stub
	}



	public MerchantFeedback(long feedback_id, String merchantresponse, String customerFeedback, String adminComment,
			String customerstatus, String merchantrstatus, long customerId, long merchantId) {
		super();
		this.feedback_id = feedback_id;
		this.merchantresponse = merchantresponse;
		this.customerFeedback = customerFeedback;
		this.adminComment = adminComment;
		this.customerstatus = customerstatus;
		this.merchantrstatus = merchantrstatus;
		this.customerId = customerId;
		this.merchantId = merchantId;
	}





	/**
	 * @return the feedback_id
	 */
	public final long getFeedback_id() {
		return feedback_id;
	}




	/**
	 * @param feedback_id the feedback_id to set
	 */
	public final void setFeedback_id(long feedback_id) {
		this.feedback_id = feedback_id;
	}




	/**
	 * @return the merchantresponse
	 */
	public final String getMerchantresponse() {
		return merchantresponse;
	}




	/**
	 * @param merchantresponse the merchantresponse to set
	 */
	public final void setMerchantresponse(String merchantresponse) {
		this.merchantresponse = merchantresponse;
	}




	/**
	 * @return the customerFeedback
	 */
	public final String getCustomerFeedback() {
		return customerFeedback;
	}




	/**
	 * @param customerFeedback the customerFeedback to set
	 */
	public final void setCustomerFeedback(String customerFeedback) {
		this.customerFeedback = customerFeedback;
	}




	/**
	 * @return the adminComment
	 */
	public final String getAdminComment() {
		return adminComment;
	}




	/**
	 * @param adminComment the adminComment to set
	 */
	public final void setAdminComment(String adminComment) {
		this.adminComment = adminComment;
	}




	/**
	 * @return the customerstatus
	 */
	public final String getCustomerstatus() {
		return customerstatus;
	}




	/**
	 * @param customerstatus the customerstatus to set
	 */
	public final void setCustomerstatus(String customerstatus) {
		this.customerstatus = customerstatus;
	}




	/**
	 * @return the merchantrstatus
	 */
	public final String getMerchantrstatus() {
		return merchantrstatus;
	}




	/**
	 * @param merchantrstatus the merchantrstatus to set
	 */
	public final void setMerchantrstatus(String merchantrstatus) {
		this.merchantrstatus = merchantrstatus;
	}




	/**
	 * @return the customerId
	 */
	public final long getCustomerId() {
		return customerId;
	}




	/**
	 * @param customerId the customerId to set
	 */
	public final void setCustomerId(long customerId) {
		this.customerId = customerId;
	}




	/**
	 * @return the merchantId
	 */
	public final long getMerchantId() {
		return merchantId;
	}




	/**
	 * @param merchantId the merchantId to set
	 */
	public final void setMerchantId(long merchantId) {
		this.merchantId = merchantId;
	}



	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MerchantFeedback [feedback_id=" + feedback_id + ", merchantresponse=" + merchantresponse
				+ ", customerFeedback=" + customerFeedback + ", adminComment=" + adminComment + ", customerstatus="
				+ customerstatus + ", merchantrstatus=" + merchantrstatus + ", customerId=" + customerId
				+ ", merchantId=" + merchantId + "]";
	}



	

	


	 
















	








	

}