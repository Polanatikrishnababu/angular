import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CustCartComponent } from './Customers/cust-cart/cust-cart.component';
import { CustFeedBackComponent } from './Customers/cust-feed-back/cust-feed-back.component';
import { CustFeedBackMerchantComponent } from './Customers/cust-feed-back-merchant/cust-feed-back-merchant.component';
import { CustFeedBackProductComponent } from './Customers/cust-feed-back-product/cust-feed-back-product.component';
import { CustHomeComponent } from './Customers/cust-home/cust-home.component';
import { CustOrdersStatusComponent } from './Customers/cust-orders-status/cust-orders-status.component';
import { CustPaymentComponent } from './Customers/cust-payment/cust-payment.component';
import { CustProfileComponent } from './Customers/cust-profile/cust-profile.component';
import { CustWishListComponent } from './Customers/cust-wish-list/cust-wish-list.component';
import { AppComponent } from './app.component';


const routes: Routes = [

   {
     path:'app-root',
     component:AppComponent
   },
  {
    path:'app-cust-home',
    component:CustHomeComponent
  },

  {
    path:'app-cust-home/app-cust-cart',
    component:CustCartComponent
  },
  {
    path:'app-cust-home/app-cust-feed-back',
    component:CustFeedBackComponent
  },
  
  {
    path:'app-cust-feed-back-merchant',
    component:CustFeedBackMerchantComponent
  },

  {
    path:'app-cust-feed-back-product',
    component:CustFeedBackProductComponent
  },

  {
    path:'app-cust-home/app-cust-orders-status',
    component:CustOrdersStatusComponent
  },
  {
    path:'app-cust-payment',
    component:CustPaymentComponent
  },
  {
    path:'app-cust-profile',
    component:CustProfileComponent
  },
  {
    path:'app-cust-home/app-cust-wish-list',
    component:CustWishListComponent
  }
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
