export class MerchantFeedback {
    merchantId: number;
    merchantFeedback: string;
    
    
    constructor( merchantId: number,merchantFeedback: string) {
    this.merchantFeedback=merchantFeedback;
    this.merchantId=merchantId;
    }
    }