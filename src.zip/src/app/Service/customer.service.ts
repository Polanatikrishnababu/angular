import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  http: HttpClient;
  merchantfeedback: MerchantFeedback[]=[];
  router: Router;

  constructor(http: HttpClient,router: Router) {
    this.http=http;
   }
   fetched:boolean=false;
   fetchDetails()
   {
     this.http.get('./assets/MerchantFeedback.json')
     .subscribe(data=>
      {if(!this.fetched)
        {
          this.convert(data);
          this.fetched=true;
        }
      });
   }
   getDetails(): MerchantFeedback[]
   {
     return this.merchantfeedback;
   }
   convert(data: any) {
    for (let o of data) {
      let e = new MerchantFeedback(o.merchantId,o.merchantFeedback)
      this.merchantfeedback.push(e);}
   }
   
  createdFlag: boolean = false;
  createdFeedBack: MerchantFeedback;
   sendFeedback(data: any) {
    this.createdFeedBack=new MerchantFeedback(data.merchantId, data.merchantFeedback);
    
    alert("Feedback sent Succesfully!!!");
    

  }
}
export class MerchantFeedback {
  merchantId: number;
  merchantFeedback: string;
  constructor( merchantId: number,merchantFeedback: string) {
  this.merchantFeedback=merchantFeedback;
  this.merchantId=merchantId;
  }
  }
