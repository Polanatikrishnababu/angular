import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/Service/customer.service';
import { MerchantFeedback } from 'src/app/Entity/MerchantFeedback';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cust-feed-back-merchant',
  templateUrl: './cust-feed-back-merchant.component.html',
  styleUrls: ['./cust-feed-back-merchant.component.css']
})
export class CustFeedBackMerchantComponent implements OnInit {
customerservice: CustomerService;
router:Router;
merchantfeedback: MerchantFeedback[]=[];
issendFeedback: boolean = true;
  constructor(customerservice: CustomerService,router:Router) { 
    this.customerservice=customerservice;
  }

sendFeedback(id:number)
{
  
  this.customerservice.sendFeedback(id);
  this.router.navigate(['app-cust-home']);
}

  ngOnInit() {
    this.customerservice.fetchDetails();
    this.merchantfeedback = this.customerservice.getDetails();
  }

}
