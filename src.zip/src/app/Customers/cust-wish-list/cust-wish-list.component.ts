import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-wish-list',
  templateUrl: './cust-wish-list.component.html',
  styleUrls: ['./cust-wish-list.component.css']
})
export class CustWishListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
