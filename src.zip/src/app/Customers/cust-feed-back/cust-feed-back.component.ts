import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-feed-back',
  templateUrl: './cust-feed-back.component.html',
  styleUrls: ['./cust-feed-back.component.css']
})
export class CustFeedBackComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
