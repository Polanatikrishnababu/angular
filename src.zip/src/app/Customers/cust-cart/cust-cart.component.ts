import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-cart',
  templateUrl: './cust-cart.component.html',
  styleUrls: ['./cust-cart.component.css']
})
export class CustCartComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
