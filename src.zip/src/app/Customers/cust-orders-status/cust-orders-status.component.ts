import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cust-orders-status',
  templateUrl: './cust-orders-status.component.html',
  styleUrls: ['./cust-orders-status.component.css']
})
export class CustOrdersStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
